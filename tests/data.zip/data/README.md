Download the test files from: https://github.com/nadirlc/toc/tree/master/tests/data to this folder
